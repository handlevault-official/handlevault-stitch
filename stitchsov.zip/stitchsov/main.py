import io, os
from flask import Flask, request, send_file, render_template_string, abort
from stitch import make_pattern, build_pdf

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 12 * 1024 * 1024

PAGE = """<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1">
<title>StitchSov</title>
<style>:root{color-scheme:light dark}body{font:16px system-ui;max-width:520px;margin:40px auto;padding:0 16px}
label{display:block;margin:14px 0 4px;font-weight:600}input,select,button{width:100%;padding:10px;font-size:16px;box-sizing:border-box}
button{margin-top:20px;cursor:pointer;font-weight:700}small{opacity:.7}</style>
<h1>🧵 StitchSov</h1><p>Turn any image into a printable cross-stitch pattern PDF.<br>
<small>Sovereign by design: runs on your own server, no third-party APIs, nothing stored.</small></p>
<form method=post action=/generate enctype=multipart/form-data>
<label>Image</label><input type=file name=image accept="image/*" required>
<label>Title</label><input name=title value="My Cross-Stitch Pattern" maxlength=60>
<label>Width in stitches (20-200)</label><input type=number name=width value=80 min=20 max=200>
<label>Max thread colors (2-40)</label><input type=number name=colors value=16 min=2 max=40>
<label>Aida fabric count</label><select name=fabric><option>11<option selected>14<option>16<option>18</select>
<button>Generate PDF</button></form>"""

@app.get("/")
def home():
    return render_template_string(PAGE)

@app.post("/generate")
def generate():
    f = request.files.get("image")
    if not f: abort(400, "No image uploaded")
    try:
        width = min(200, max(20, int(request.form.get("width", 80))))
        colors = min(40, max(2, int(request.form.get("colors", 16))))
        fabric = int(request.form.get("fabric", 14))
        title = (request.form.get("title") or "Cross-Stitch Pattern")[:60]
        grid, legend = make_pattern(f.read(), width, colors)
        pdf = build_pdf(grid, legend, fabric, title)
    except Exception as e:
        abort(400, f"Could not process image: {e}")
    return send_file(io.BytesIO(pdf), mimetype="application/pdf", as_attachment=True,
                     download_name="cross-stitch-pattern.pdf")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
