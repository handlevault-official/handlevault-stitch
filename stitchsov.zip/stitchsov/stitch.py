"""StitchSov core: image -> DMC cross-stitch grid -> PDF. No network, no storage."""
import io, math
import numpy as np
from PIL import Image, ImageOps
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader

# Approximate DMC RGB values. Extend/correct freely (code r g b).
DMC_RAW = """310 0 0 0|B5200 255 255 255|ECRU 240 234 218|712 255 251 239|739 248 228 200|738 236 204 158
437 228 187 142|436 203 144 81|434 152 94 51|801 101 57 25|938 54 31 14|3371 30 17 8|3782 210 188 166
3781 107 87 67|3031 75 60 42|3045 188 150 106|3820 223 182 95|3821 243 206 117|745 255 233 173
743 254 211 118|307 253 237 84|444 255 214 0|972 255 181 21|741 255 163 43|740 255 131 19|970 247 139 19
900 209 88 7|402 247 167 119|400 143 67 15|300 111 47 0|754 247 203 191|758 238 170 155|352 253 156 151
350 224 72 87|321 199 43 59|666 227 29 66|817 187 5 31|816 151 11 35|3706 255 121 140|604 255 176 213
603 255 164 190|602 226 72 116|601 209 40 106|915 130 0 67|211 227 203 227|209 163 123 167|208 148 91 128
341 163 174 209|340 173 167 199|333 92 84 120|800 192 204 222|799 116 142 182|798 70 106 142|797 19 71 125
820 14 54 92|519 166 221 233|518 79 147 167|3846 6 227 230|3844 18 174 186|943 61 147 132|3812 32 141 133
3348 204 217 177|3347 113 147 92|3345 27 89 21|895 27 83 0|890 23 73 35|704 158 207 52|703 123 181 71
702 71 167 47|701 63 143 41|699 5 101 23|905 98 138 40|762 236 236 236|415 211 211 214|318 171 171 171
414 140 140 140|317 108 108 108|413 86 86 86|3799 66 66 66"""
DMC = []
for chunk in DMC_RAW.replace("\n", "|").split("|"):
    p = chunk.split()
    DMC.append((p[0], tuple(int(x) for x in p[1:4])))
SYMBOLS = list("ABCDEFGHJKLMNPQRSTUVWXYZabdefghkmnqrty23456789#@%&*+=?/<>~^$")

def _lab(rgb):
    a = np.asarray(rgb, float) / 255.0
    a = np.where(a > 0.04045, ((a + 0.055) / 1.055) ** 2.4, a / 12.92)
    m = np.array([[.4124, .3576, .1805], [.2126, .7152, .0722], [.0193, .1192, .9505]])
    xyz = a @ m.T / np.array([.95047, 1, 1.08883])
    f = np.where(xyz > .008856, np.cbrt(xyz), 7.787 * xyz + 16 / 116)
    return np.stack([116 * f[..., 1] - 16, 500 * (f[..., 0] - f[..., 1]), 200 * (f[..., 1] - f[..., 2])], -1)

DMC_LAB = _lab([c for _, c in DMC])

def make_pattern(data, width=80, colors=20):
    img = ImageOps.exif_transpose(Image.open(io.BytesIO(data)))
    if img.mode in ("RGBA", "LA", "P"):
        img = img.convert("RGBA")
        bg = Image.new("RGBA", img.size, (255, 255, 255, 255)); bg.alpha_composite(img); img = bg
    img = img.convert("RGB")
    h = max(1, round(img.height * width / img.width))
    img = img.resize((width, h), Image.LANCZOS)
    q = np.array(img.quantize(colors=colors, method=Image.MEDIANCUT, dither=Image.NONE).convert("RGB"))
    uniq, inv = np.unique(q.reshape(-1, 3), axis=0, return_inverse=True)
    d = ((_lab(uniq)[:, None, :] - DMC_LAB[None, :, :]) ** 2).sum(-1)
    dmc_idx = d.argmin(1)[inv.reshape(-1)].reshape(h, width)
    ids, counts = np.unique(dmc_idx, return_counts=True)
    order = ids[np.argsort(-counts)]
    legend, remap = [], {}
    for n, i in enumerate(order):
        remap[i] = n
        legend.append(dict(code=DMC[i][0], rgb=DMC[i][1], sym=SYMBOLS[n % len(SYMBOLS)],
                           count=int(counts[list(ids).index(i)])))
    grid = np.vectorize(remap.get)(dmc_idx)
    return grid, legend

def build_pdf(grid, legend, fabric=14, title="Cross-Stitch Pattern"):
    H, W = grid.shape
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    c.setTitle(title)
    PW, PH = A4
    # ---- cover ----
    c.setFont("Helvetica-Bold", 22); c.drawString(40, PH - 60, title)
    c.setFont("Helvetica", 10)
    fw, fh = W / fabric, H / fabric
    c.drawString(40, PH - 80, f"{W} x {H} stitches  |  {fabric}-count Aida  |  design {fw:.1f} x {fh:.1f} in "
                              f"({fw*2.54:.1f} x {fh*2.54:.1f} cm)  |  suggested fabric {fw+6:.0f} x {fh+6:.0f} in")
    c.drawString(40, PH - 94, f"{len(legend)} thread colors (DMC)  |  Generated offline by StitchSov")
    pal = np.array([l["rgb"] for l in legend], np.uint8)
    prev = Image.fromarray(pal[grid]).resize((W * 6, H * 6), Image.NEAREST)
    mw, mh = PW - 80, 330
    s = min(mw / prev.width, mh / prev.height)
    c.drawImage(ImageReader(prev), 40, PH - 110 - prev.height * s, prev.width * s, prev.height * s)
    y = PH - 130 - prev.height * s

    def head(y):
        c.setFont("Helvetica-Bold", 9)
        c.drawString(40, y, "Swatch"); c.drawString(90, y, "Symbol"); c.drawString(140, y, "DMC")
        c.drawString(210, y, "Stitches"); c.drawString(280, y, "Skeins (est.)")
        return y - 16
    y = head(y)
    c.setFont("Helvetica", 10)
    per_skein = 1600 * fabric / 14  # rough, 2 strands
    for l in legend:
        if y < 50:
            c.showPage(); y = head(PH - 50); c.setFont("Helvetica", 10)
        c.setFillColorRGB(*[v / 255 for v in l["rgb"]]); c.rect(40, y - 3, 35, 12, fill=1, stroke=1)
        c.setFillColorRGB(0, 0, 0)
        c.drawString(98, y, l["sym"]); c.drawString(140, y, l["code"])
        c.drawString(210, y, str(l["count"])); c.drawString(280, y, str(max(1, math.ceil(l["count"] / per_skein))))
        y -= 17
    c.showPage()
    # ---- chart tiles ----
    CS, TC, TR = 10, 50, 70
    left, top = (PW - TC * CS) / 2, PH - 55
    tiles = [(r, k) for r in range(0, H, TR) for k in range(0, W, TC)]
    for n, (r0, c0) in enumerate(tiles, 1):
        r1, c1 = min(r0 + TR, H), min(c0 + TC, W)
        for r in range(r0, r1):
            for k in range(c0, c1):
                l = legend[grid[r, k]]
                x, yy = left + (k - c0) * CS, top - (r - r0 + 1) * CS
                c.setFillColorRGB(*[1 - (1 - v / 255) * .35 for v in l["rgb"]])
                c.setStrokeColorRGB(.7, .7, .7); c.setLineWidth(.25)
                c.rect(x, yy, CS, CS, fill=1, stroke=1)
                c.setFillColorRGB(0, 0, 0); c.setFont("Helvetica", 7)
                c.drawCentredString(x + CS / 2, yy + 2.6, l["sym"])
        c.setStrokeColorRGB(0, 0, 0); c.setLineWidth(1); c.setFont("Helvetica", 6)
        for k in range(c0, c1 + 1):
            if k % 10 == 0:
                x = left + (k - c0) * CS
                c.line(x, top, x, top - (r1 - r0) * CS); c.drawCentredString(x, top + 4, str(k))
        for r in range(r0, r1 + 1):
            if r % 10 == 0:
                yy = top - (r - r0) * CS
                c.line(left, yy, left + (c1 - c0) * CS, yy); c.drawRightString(left - 3, yy - 2, str(r))
        c.setFont("Helvetica", 8)
        c.drawString(left, 25, f"Page {n}/{len(tiles)}  -  columns {c0+1}-{c1}, rows {r0+1}-{r1}  -  centre = (col {W//2}, row {H//2})")
        c.showPage()
    c.save()
    return buf.getvalue()
